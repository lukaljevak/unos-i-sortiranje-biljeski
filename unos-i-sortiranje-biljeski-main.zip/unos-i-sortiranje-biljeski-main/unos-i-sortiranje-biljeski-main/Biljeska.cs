﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace UnosBiljeski
{
    public class Biljeska 
    {
        public string Naslov { get; set; }
        public string Opis { get; set; }

        public Biljeska() { }

        public Biljeska(string naslov, string opis)
        {
            Naslov = naslov;
            Opis = opis;
        }
    }
}
